1) Extract this zip to your target directory.
2) Open "Open Align42 Home.command" or open Align42/Align42.html directly.
