@echo off
set "APP_HTML=%~dp0Align42\Align42.html"
if not exist "%APP_HTML%" (
  echo Align42.html was not found in "%~dp0Align42".
  echo Ensure the zip was fully extracted before launching.
  pause
  exit /b 1
)
start "" "%APP_HTML%"
