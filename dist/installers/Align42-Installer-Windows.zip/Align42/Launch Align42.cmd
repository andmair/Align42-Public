@echo off
start "" "%~dp0Align42.html"
