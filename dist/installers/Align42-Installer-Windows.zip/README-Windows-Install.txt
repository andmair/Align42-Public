1) Extract this zip to your target directory.
2) Open Align42/Align42.html in your browser.
