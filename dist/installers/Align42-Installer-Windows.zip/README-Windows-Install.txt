1) Extract this zip to your target directory.
2) Open "Open Align42 Home.cmd" to launch the app home page.
